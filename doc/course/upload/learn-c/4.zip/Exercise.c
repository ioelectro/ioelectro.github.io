#include <stdio.h>

void guessNumber(int guess) {
    // TODO: write your code here
}

int main() {
    guessNumber(500);
    guessNumber(600);
    guessNumber(555);
}

/**
 * Morse Decoder
 * By IOElectro
 * 1401/08/14
 */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define BUFFER_SIZE 256

// 26 Code + 10 Num
const char morse[][6]={".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--..","-----",".----","..---","...--","....-",".....","-....","--...","---..","----."};

int serchMorse(char sign[])
{
    int i,s;
    s=sizeof(morse)/sizeof(morse[0]);
    for(i=0;i<s;i++)if(!strncmp(sign,morse[i],6))return i;
    return -1;
}

int main()
{
    int j=0,i=0;
    char buf[BUFFER_SIZE],mBuf[6];
    gets(buf);
    while(1)
    {
        if(buf[j]=='.'||buf[j]=='-')
        {
            if(i<6)mBuf[i++]=buf[j];
        }
        else if(buf[j]==' '||buf[j]=='\0'||buf[j]=='/')
        {
            if(!i)
            {
                if(buf[j]=='/')putchar(' ');
                if(buf[j]!='\0')j++;
                else break;
                continue;
            }
            mBuf[i]='\0';
            i=serchMorse(mBuf);
            if(i<0)putchar('?');
            else if(i<26)putchar('A'+i);
            else putchar('0'+i-26);
            if(buf[j]=='/')putchar(' ');
            else if(buf[j]=='\0')break;
            i=0;
        }
        else i=0;
        j++;
    }
    return 0;
}
/**
 * Morse Decoder
 * By @rezabakhshi_98
 * Sponsored by IOElectro
 * 1401/08/13
 */

#include <stdio.h>
#include <string.h>

char input[300];
char output[100];
char *morseAlphabet[] = {".-", "-...", "-.-.", "-..", ".", "..-.",
                         "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-",
                         ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."}; // a-z
char *morseNumber[] = {"-----", ".----", "..---", "...--", "....-",
                       ".....", "-....", "--...", "---..", "----."}; // 0-9
char buffer[50];
unsigned char counter = 0, outputCounter = 0;

char findCharacter(char in[])
{
    if (strlen(in) < 5)
    {
        for (int a = 0; a < 26; a++)
        {
            if (strcmp(in, morseAlphabet[a]) == 0)
            {
               return 'A' + a;
            }
        }
    }
    else
    {
        for (int a = 0; a < 10; a++)
        {
            if (strcmp(in, morseNumber[a]) == 0)
            {
                return '0' + a;
            }
 
        }
    }
    return '?';
}

int main()
{
    printf("Enter morse code: ");
    scanf("%[^\n]", input);
    for (int a = 0; a < strlen(input)+1; a++)
    {
        if ((input[a] == 32))
        {
            output[outputCounter++] = findCharacter(buffer);

            memset(buffer, '\0', 50);
            counter = 0;
        }
        else if (input[a] == '/')
        {
            output[outputCounter++] = ' ';
            a++;
        }
        else
        {
            buffer[counter] = input[a];
            counter++;
        }
    }
    if(counter>1)
    {
     output[outputCounter++]='?';
     counter=0;  
    }
    printf("your text: %s", output);
    return 0;
}
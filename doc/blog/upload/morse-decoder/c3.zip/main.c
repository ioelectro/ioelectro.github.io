/**
 * Morse Decoder
 * By @theghaffarzadeh
 * Sponsored by IOElectro
 * 1401/08/13
 */

#include <stdio.h>
#include <conio.h>
#include <string.h>

#define mors_A	".-"
#define mors_B	"-..."
#define mors_C	"-.-."
#define mors_D	"-.."
#define mors_E	"."
#define mors_F	"..-."
#define mors_G	"--."
#define mors_H	"...."
#define mors_I	".."
#define mors_J	".---"
#define mors_K	"-.-"
#define mors_L	".-.."
#define mors_M	"--"
#define mors_N	"-."
#define mors_O	"---"
#define mors_P	".--."
#define mors_Q	"--.-"
#define mors_R	".-."
#define mors_S	"..."
#define mors_T	"-"
#define mors_U	"..-"
#define mors_V	"...-"
#define mors_W	".--"
#define mors_X	"-..-"
#define mors_Y	"-.--"
#define mors_Z	"--.."
#define mors_1	".----"
#define mors_2	"..---"
#define mors_3	"...--"
#define mors_4	"....-"
#define mors_5	"....."
#define mors_6	"-...."
#define mors_7	"--..."
#define mors_8	"---.."
#define mors_9	"----."
#define mors_0	"-----"

char str[100];
char mors[7];
char c;
int i=0,j=0;

void clear(void)
{
	for(int a=0;a<6;a++)
	{
		mors[a]='\0';
	}
    j=0;
}

int mors_dec()
{

    if(strcmp(mors,mors_A)==0)str[i]='A';
    else if(strcmp(mors,mors_B)==0)str[i]='B';
    else if(strcmp(mors,mors_C)==0)str[i]='C';
    else if(strcmp(mors,mors_D)==0)str[i]='D';
    else if(strcmp(mors,mors_E)==0)str[i]='E';
    else if(strcmp(mors,mors_F)==0)str[i]='F';
    else if(strcmp(mors,mors_G)==0)str[i]='G';
    else if(strcmp(mors,mors_H)==0)str[i]='H';
    else if(strcmp(mors,mors_I)==0)str[i]='I';
    else if(strcmp(mors,mors_J)==0)str[i]='J';
    else if(strcmp(mors,mors_K)==0)str[i]='K';
    else if(strcmp(mors,mors_L)==0)str[i]='L';
    else if(strcmp(mors,mors_M)==0)str[i]='M';
    else if(strcmp(mors,mors_N)==0)str[i]='N';
    else if(strcmp(mors,mors_O)==0)str[i]='O';
    else if(strcmp(mors,mors_P)==0)str[i]='P';
    else if(strcmp(mors,mors_Q)==0)str[i]='Q';
    else if(strcmp(mors,mors_R)==0)str[i]='R';
    else if(strcmp(mors,mors_S)==0)str[i]='S';
    else if(strcmp(mors,mors_T)==0)str[i]='T';
    else if(strcmp(mors,mors_U)==0)str[i]='U';
    else if(strcmp(mors,mors_V)==0)str[i]='V';
    else if(strcmp(mors,mors_W)==0)str[i]='W';
    else if(strcmp(mors,mors_X)==0)str[i]='X';
    else if(strcmp(mors,mors_Y)==0)str[i]='Y';
    else if(strcmp(mors,mors_Z)==0)str[i]='Z';
    else if(strcmp(mors,mors_1)==0)str[i]='1';
    else if(strcmp(mors,mors_2)==0)str[i]='2';
    else if(strcmp(mors,mors_3)==0)str[i]='3';
    else if(strcmp(mors,mors_4)==0)str[i]='4';
    else if(strcmp(mors,mors_5)==0)str[i]='5';
    else if(strcmp(mors,mors_6)==0)str[i]='6';
    else if(strcmp(mors,mors_7)==0)str[i]='7';
    else if(strcmp(mors,mors_8)==0)str[i]='8';
    else if(strcmp(mors,mors_9)==0)str[i]='9';
    else if(strcmp(mors,mors_0)==0)str[i]='0';
    else return -1;
	i++;
    return 0;
}

int main (void)
{
    while(c!='\r')
    {
        c=getch();
        putchar(c);
        if((c=='.') || (c=='-'))
        {
            if(j<6)mors[j++]=c;
        }
        else if(c==' ')
        {
            mors[j]='\0';
            if(mors_dec())if(j)str[i++]='?';
            clear();
        }
        else if(c=='/')str[i++]=' ';
    }
    str[i]='\0';
    printf("\r\n");
    puts(str);
    return 0;
}

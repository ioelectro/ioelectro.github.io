/**
 * Morse Decoder
 * By @vdarioush
 * Sponsored by IOElectro
 * 1401/08/13
 */

 #include "main.h"

int main(int argc, char *argv[]) {
    char code[500];
    char result[100];
    int i=0, counter = 0;
    int index=1;
    int whitespace = 0;    //Whitespace and " / " flag
    scanf("%[^\n]s", code);
    do
    {
        if(code[i]!=' ' && code[i]!='/')
        {
            whitespace = 0;
            if(code[i] == '.')
                index = index * 2;
            else if (code[i] == '-')
                index = index*2 + 1;
            else
                break;
        }
        else if(code[i]==' ')
        {
            if(!whitespace)
            {
                result[counter] = morse_tree[index];
                counter++;
                index=1;
            }
            whitespace = 1;
            
        }
        else
        {
            if(!whitespace)
            {
                result[counter] = morse_tree[index];
                counter++;
                index=1;
            }
            result[counter] = ' ';
            counter++;
            whitespace = 1;         
        }
        i++;
    }while(code[i]);
    if(index!=1)
        result[counter] = morse_tree[index];    //Last character
    counter++;
    result[counter] = '\0';
    printf("%s",result);
}

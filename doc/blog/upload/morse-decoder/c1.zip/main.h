/**
 * Morse Decoder
 * By @vdarioush
 * Sponsored by IOElectro
 * 1401/08/13
 */

#ifndef _MAIN_H_
#define _MAIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

const char morse_tree[64] = 
{
    '?',
    '?',
    'E',
    'T',
    'I',
    'A',
    'N',
    'M',
    'S',
    'U',
    'R',
    'W',
    'D',
    'K',
    'G',
    'O',
    'H',
    'V',
    'F',
    '?',
    'L',
    '?',
    'P',
    'J',
    'B',
    'X',
    'C',
    'Y',
    'Z',
    'Q',
    '?',
    '?',
    '5',
    '4',
    '?',
    '3',
    '?',
    '?',
    '?',
    '2',
    '?',
    '?',
    '+',
    '?',
    '?',
    '?',
    '?',
    '1',
    '6',
    '=',
    '/',    //Slash is going to be the word dividers
    '?',
    '?',
    '?',
    '?',
    '?',
    '7',
    '?',
    '?',
    '?',
    '8',
    '?',
    '9',
    '0'
};


#endif